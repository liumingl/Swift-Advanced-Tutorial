//
//  OrderedDictionary.swift
//  FlickrSearch
//
//  Created by 刘铭 on 15/7/6.
//  Copyright © 2015年 Razeware. All rights reserved.
//

import Foundation

struct OrderedDictionary<KeyType: Hashable, ValueType> {
    typealias ArrayType = [KeyType]
    typealias DictionaryType = [KeyType: ValueType]
    
    var array = ArrayType()
    var dictionary = DictionaryType()
    
    var count: Int {
        return self.array.count
    }
    
    subscript(key: KeyType) -> ValueType? {
        get {
            return self.dictionary[key]
        }
        
        set {
            if let _ = self.array.indexOf(key) {}else {
                self.array.append(key)
            }
            
            self.dictionary[key] = newValue
        }
    }
    
    subscript(index: Int) ->(KeyType, ValueType) {
        get {
            precondition(index < self.array.count, "Index 超出范围")
            
            let key = self.array[index]
            
            let value = self.dictionary[key]!
            
            return (key, value)
        }
    }
    
    mutating func removeAtIndex(index: Int) -> (KeyType, ValueType) {
        precondition(index < self.array.count, "Index 超出范围")
        assert(index < self.array.count)
        
        let key = self.array.removeAtIndex(index)
        
        let value = self.dictionary.removeValueForKey(key)!
        
        return (key, value)
    }
    
    mutating func insert(value: ValueType, forKey key: KeyType, atIndex index:Int) -> ValueType? {
        var adjustedIndex = index
        
        let existingValue = self.dictionary[key]
        
        if existingValue != nil {
            let existingIndex = self.array.indexOf(key)
            
            if existingIndex < index {
                adjustedIndex--
            }
            
            self.array.removeAtIndex(existingIndex!)
        }
        
        self.array.insert(key, atIndex: adjustedIndex)
        self.dictionary[key] = value
        
        return existingValue
    }
}