//
//  Place.swift
//  MyLocation
//
//  Created by 刘铭 on 15/6/29.
//  Copyright © 2015年 刘铭. All rights reserved.
//

import Foundation
import MapKit

protocol Alertable {
    func alert() -> UIAlertController
}

class Place: NSObject {
    let what: String
    let location: GeoLocation
    
    init (what: String, location: GeoLocation){
        self.what = what
        self.location = location
    }
    
    convenience init(what: String, latitude: Double, longitude: Double) {
        let location = GeoLocation(latitude: latitude, longitude: longitude)
        self.init(what: what, location: location)
        
    }
    
    func pinColor() -> UIColor {
        return MKPinAnnotationView.redPinColor()
    }
}

extension Place: MKAnnotation {
    var coordinate: CLLocationCoordinate2D {
        return self.location.coordinate
    }
    
    var title: String? {
        return self.what
    }
}

final class PlaceOfInterest: Place {
    let year: Int16
    
    init(what: String, year: Int16, latitude: Double, longitude: Double) {
        self.year = year
        let location = GeoLocation(latitude: latitude, longitude: longitude)
        super.init(what: what, location: location)
    }
    
    override func pinColor() -> UIColor {
        return MKPinAnnotationView.greenPinColor()
    }
}

extension PlaceOfInterest: Alertable {
    func alert() -> UIAlertController {
        let alert = UIAlertController(title: "名胜古迹", message: "始建于：\(year)年的\(what)", preferredStyle: UIAlertControllerStyle.Alert)
        return alert
    }
}

final class University: Place {
    let name: String
    
    init(what: String, name: String, latitude: Double, longitude: Double) {
        self.name = name
        let location = GeoLocation(latitude: latitude, longitude: longitude)
        super.init(what: what, location: location)
    }
    
    override func pinColor() -> UIColor {
        return MKPinAnnotationView.purplePinColor()
    }
}

extension University: Alertable {
    func alert() -> UIAlertController {
        let alert = UIAlertController(title: "北京的著名大学", message: "\(name)", preferredStyle: UIAlertControllerStyle.Alert)
        return alert
    }
}

final class Restaurant: Place {
    let specialty: String
    
    init(what: String, specialty: String, latitude: Double, longitude: Double) {
        self.specialty = specialty
        let location = GeoLocation(latitude: latitude, longitude: longitude)
        super.init(what: what, location: location)
    }
}

extension Restaurant: Alertable {
    func alert() -> UIAlertController {
        let alert = UIAlertController(title: "北京的美食", message: "\(what)，特色菜：\(specialty)", preferredStyle: UIAlertControllerStyle.Alert)
        return alert
    }
}
