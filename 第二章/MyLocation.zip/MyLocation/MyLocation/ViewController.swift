//
//  ViewController.swift
//  MyLocation
//
//  Created by 刘铭 on 15/6/29.
//  Copyright © 2015年 刘铭. All rights reserved.
//

import UIKit
import MapKit

class ViewController: UIViewController {

    @IBOutlet weak var mapView: MKMapView!
    private var places: [Place] = []
    
    private var foundLocation: [GeoLocation] = []
    private var polyline: MKPolyline!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.places = [
            PlaceOfInterest(what: "故宫", year: 1406, latitude: 39.916803, longitude: 116.397054),
            PlaceOfInterest(what: "天坛", year: 1420, latitude: 39.883745, longitude: 116.412861),
            University(what: "北京著名大学", name: "北京大学", latitude: 39.987119, longitude: 116.305852),
            University(what: "北京著名大学", name: "清华大学", latitude: 39.999861, longitude: 116.326422),
            Restaurant(what: "全聚德烤鸭店", specialty: "挂炉烤鸭", latitude: 39.899609, longitude: 116.385051),
            Restaurant(what: "便宜坊烤鸭店", specialty: "焖炉烤鸭", latitude: 39.896732, longitude:  116.400892)]

        self.mapView.delegate = self
        self.mapView.addAnnotations(self.places)
        
        let rectToDisplay = self.places.reduce(MKMapRectNull) {
            (mapRect:MKMapRect, place: Place) -> MKMapRect in
            let placePointRect = MKMapRect(origin: place.location.mapPoint, size: MKMapSize(width: 0, height: 0))
            return MKMapRectUnion(mapRect, placePointRect)
        }
        
        self.mapView.setVisibleMapRect(rectToDisplay, edgePadding: UIEdgeInsetsMake(74, 10, 10, 10), animated: true)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    private func markPlaceAsFound(place: Place) {
        if let index = self.foundLocation.indexOf(place.location) {
            let alert = UIAlertController(title: "Oops",
                message: "你已经找到了这个位置，在第\(index+1)步的时候。",
                preferredStyle: UIAlertControllerStyle.Alert)
            alert.addAction(UIAlertAction(title: "OK",
                style: UIAlertActionStyle.Default,
                handler: nil))
            self.presentViewController(alert, animated: true, completion: nil)
        }else {
            self.foundLocation.append(place.location)
            
            if self.polyline != nil {
                self.mapView.removeOverlay(self.polyline)
            }
            
            var coordinates = self.foundLocation.map{
                $0.coordinate
            }
            
            self.polyline = MKPolyline(coordinates: &coordinates, count: coordinates.count)
            self.mapView.addOverlay(self.polyline)
        }
    }
}

extension ViewController: MKMapViewDelegate {
    func mapView(mapView: MKMapView, rendererForOverlay overlay: MKOverlay) -> MKOverlayRenderer {
        if let polylineOverlay = overlay as? MKPolyline{
            let renderer = MKPolylineRenderer(polyline: polylineOverlay)
            renderer.strokeColor = UIColor.blueColor()
            return renderer
        }
        return MKPolylineRenderer()
    }
    
    
    func mapView(mapView: MKMapView, annotationView view: MKAnnotationView, calloutAccessoryControlTapped control: UIControl) {
        
        if let place = view.annotation as? Place {
            if let alertable  = place as? Alertable {
                let alert = alertable.alert()
                alert.addAction(UIAlertAction(title: "查找最近的地点",
                    style: UIAlertActionStyle.Default,
                    handler: { (action) -> Void in
                        var sortedPlaces = self.places
                        sortedPlaces.sortInPlace{
                            let distanceA = place.location.distanceBetween($0.location)
                            let distanceB = place.location.distanceBetween($1.location)
                            
                            return distanceA < distanceB
                        }
                        
                        mapView.deselectAnnotation(place, animated: true)
                        mapView.selectAnnotation(sortedPlaces[1], animated: true)
                }))
                
                alert.addAction(UIAlertAction(title: "找到",
                    style: UIAlertActionStyle.Default,
                    handler: { (action) -> Void in
                        self.markPlaceAsFound(place)
                }))
                
                alert.addAction(UIAlertAction(
                    title: "OK",
                    style: UIAlertActionStyle.Default,
                    handler: nil))
                
                self.presentViewController(alert, animated: true, completion: nil)
            }
        }
    }
    
    func mapView(mapView: MKMapView, viewForAnnotation annotation: MKAnnotation) -> MKAnnotationView? {
        if let place = annotation as? Place {
            let view: MKPinAnnotationView
            
            if let dequeueView = mapView.dequeueReusableAnnotationViewWithIdentifier("pin") as? MKPinAnnotationView {
                dequeueView.annotation = annotation
                view = dequeueView
            }else {
                view = MKPinAnnotationView(annotation: annotation, reuseIdentifier: "pin")
                view.canShowCallout = true
                view.animatesDrop = false
                view.calloutOffset = CGPoint(x: -5, y: 5)
                view.rightCalloutAccessoryView = UIButton(type: UIButtonType.DetailDisclosure) as UIView
            }
            view.pinTintColor = place.pinColor()
            return view
        }
        return nil
    }
    
    
}


